export default function About() {
	return (
	  <div>
		<p>This is the about page</p>
	  </div>
	);
  }